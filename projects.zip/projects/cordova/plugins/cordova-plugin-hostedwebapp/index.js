/**
* 
* Usage
* -----
*
*      var ManifoldCordovaPluginPath = require('ManifoldCordova');
*
*/

module.exports = __dirname;
